
export const env = {
  apiBase: ""
};
