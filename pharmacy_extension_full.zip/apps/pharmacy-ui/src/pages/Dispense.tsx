import { useState } from "react";

export default function Dispense() {
  const [result, setResult] = useState<any>(null);

  async function submit() {
    const res = await fetch("/intent/pharmacy/dispense", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        medicationDispense: {
          medicationCodeableConcept: {
            text: "Opioid + Benzodiazepine",
            coding: [{ code: "12345" }]
          },
          quantity: { value: 30 },
          daysSupply: 10,
          performer: [{ actor: { identifier: { value: "DEA123" } } }]
        }
      })
    });
    setResult(await res.json());
  }

  return (
    <div>
      <h2>Pharmacy Dispense</h2>
      <button onClick={submit}>Submit</button>
      <pre>{JSON.stringify(result, null, 2)}</pre>
    </div>
  );
}
