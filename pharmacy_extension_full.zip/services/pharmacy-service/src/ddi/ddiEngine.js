const HIGH_RISK_PAIRS = [["opioid","benzodiazepine"]];

export async function scoreDDI(md) {
  const drugs = md.medicationCodeableConcept.text.toLowerCase();
  for (const [a,b] of HIGH_RISK_PAIRS) {
    if (drugs.includes(a) && drugs.includes(b)) {
      return { severity: 9, reason: "High risk respiratory depression" };
    }
  }
  return { severity: 1 };
}
