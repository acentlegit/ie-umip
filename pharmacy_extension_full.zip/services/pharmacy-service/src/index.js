import express from "express";
import { MongoClient } from "mongodb";
import { fhirToNcpdp } from "./translators/fhirToNcpdp.js";
import { scoreDDI } from "./ddi/ddiEngine.js";

const app = express();
app.use(express.json());

const db = new MongoClient(process.env.MONGO_URL || "mongodb://mongo:27017");
await db.connect();

app.post("/dispense", async (req, res) => {
  const { medicationDispense } = req.body;
  const ddi = await scoreDDI(medicationDispense);
  if (ddi.severity >= 8) {
    return res.status(403).json({ denied: true, reason: ddi.reason });
  }
  const ncpdp = fhirToNcpdp(medicationDispense);
  await db.db("pharmacy").collection("dispenses").insertOne({ medicationDispense, ncpdp });
  res.json({ success: true, ncpdp });
});

app.listen(8090, () => console.log("Pharmacy service running on :8090"));
