export function fhirToNcpdp(md) {
  return {
    TransactionCode: "B1",
    BIN: "610415",
    PCN: "UMIP",
    GroupID: md.insurance?.group || "DEFAULT",
    CardholderID: md.subject?.reference || "UNKNOWN",
    NDC: md.medicationCodeableConcept.coding[0].code,
    Quantity: md.quantity.value,
    DaysSupply: md.daysSupply,
    PrescriberID: md.performer[0].actor.identifier.value
  };
}
